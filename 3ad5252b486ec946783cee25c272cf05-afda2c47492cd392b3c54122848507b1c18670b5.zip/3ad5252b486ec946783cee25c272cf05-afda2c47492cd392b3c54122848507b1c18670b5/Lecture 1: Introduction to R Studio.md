# Lecture 1: Introduction to R Studio

Welcome to the first lecture of the course! In this session, we’ll introduce **R Studio**, a powerful Integrated Development Environment (IDE) used for R programming.



## What is R Studio?

R Studio is an open-source IDE for R that provides a user-friendly environment for writing, debugging, and running R code. It makes R programming easier by organizing your workspace, helping with package management, and providing excellent visualization capabilities.

- **Script editor**: Where you write your code.
- **Console**: Where your code gets executed and results are displayed.
- **Environment pane**: Displays all variables, datasets, and functions in your workspace.
- **History pane**: Keeps a history of all commands you’ve executed.

Here’s an example of what R Studio looks like:

![R Studio Interface](https://www.rstudio.com/wp-content/uploads/2016/03/RStudio-IDE.png)

--{{1}}--

## Why Use R Studio?

- **User-friendly Interface**: R Studio provides an easy-to-use environment that helps you work more efficiently with R.
- **Integrated Tools**: It integrates a variety of tools for code editing, data analysis, visualization, and reporting.
- **Support for R Packages**: R Studio has built-in support for thousands of R packages, making it a powerful tool for data analysis.

--{{2}}--

## How to Install R Studio?

To get started, you'll need to install **R** and **R Studio**.

### Steps:
1. Download **R** from the [official R website](https://cran.r-project.org/).
2. Download **R Studio** from the [official R Studio website](https://posit.co/download/rstudio-desktop/).

Once installed, open **R Studio**, and you’ll be ready to start writing R code.

![](49142dcae927bde572c3ea40bf03d393b9b235e1.png)

## Your First R Command

Now that you have **R Studio** set up, let’s run your first R command.

Open the R Studio **Console** and type the following:

```r
print("Hello, World!")
!?[](ae0740d3fbbc9403381d7674b0951c3997b9e705.mp4)
